# Thick Atmosphere — 2026-10-12+a37d2bb

Thin Atmosphere plus the runtime that moves it.

| Path | What it adds |
|---|---|
| `css/`, `atmosphere.css` | The eight concern sheets, as in Thin |
| `js/atmosphere.js` | Composition controller: applies axis changes, crossings, and injects the theme drawer |
| `js/atmosphere-model.js` | `window.AtmosphereModel`, a LiveObject: `set(axis, value)`, `subscribe(fn)` |
| `webcomp/atheme-drawer.*`, `webcomp/atheme-tray.*` | The theme drawer and tray web components |
| `experience_themes.json` | Lens psychology notes the drawer shows (served over http) |
| `docs/` | Vocabulary and the state model |

`index.html` is a working starter. Serve the folder over http so the
drawer can read `experience_themes.json`; from `file://` it falls back to
its built-in lens seeds.

Dual licensed under AGPL-3.0 (LICENSE-AGPL) or a MENTIC LLC commercial
license (LICENSE).
