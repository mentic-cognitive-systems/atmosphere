# Thin Atmosphere — 2026-10-12+a37d2bb

The air without the weather: Atmosphere's eight concern sheets as plain CSS.
No JavaScript. You compose a page by writing one attribute per axis on
`<body class="Layout">` and the sheets resolve how it is met.

## Use

Link the sheets one by one, in this order (see `index.html`), or link the
single `atmosphere.css`, which imports them in the same order:

| Order | Sheet | Question it answers |
|---|---|---|
| 1 | `css/at.components.css` | What shape is a part inside itself? |
| 2 | `css/at.layout.css` | Which frames exist, and where do they sit? (X × Y) |
| 3 | `css/at.lattice.css` | How does content travel through a frame? |
| 4 | `css/at.layer.css` | Is a frame in the plan or on call? (Z) |
| 5 | `css/at.look.css` | What is it made of? Surfaces, palette, type |
| 6 | `css/at.life.css` | How does it change over time? |
| 7 | `css/at.lens.css` | Which experience policy seeds the other five? |
| 8 | `css/at.local.css` | How much, at this call site? Loads last |

Axes: `data-layout`, `data-lattice`, `data-layer`, `data-look` (mirrored by
`data-theme`), `data-life`, `data-lens`, `data-density`, `data-size`.

Need live switching, the theme drawer, or a model components can subscribe
to? Download **Thick Atmosphere**.

Dual licensed under AGPL-3.0 (LICENSE-AGPL) or a MENTIC LLC commercial
license (LICENSE).
